module.exports = {
    "pathParameters": { "id": 1 }
};