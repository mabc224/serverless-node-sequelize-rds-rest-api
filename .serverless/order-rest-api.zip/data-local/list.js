module.exports = {

    "queryStringParameters": { "limit": 5, "offset": 0 }

};