module.exports = {
    'body': {
        'tenantId': '5',
        'userId': '5',
        'portalId': '4',
        'customerId': '4',
        'type': 'product',
        'category': 'sell',
        'keywords': 'item',
        'status': 'ready',
        'createdBy': 'mabc224',
        'editedBy': 'mabc224',
    }
};