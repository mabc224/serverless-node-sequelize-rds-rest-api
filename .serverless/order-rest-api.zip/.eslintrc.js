module.exports = {
    extends: 'google',
    parserOptions: {
        ecmaVersion: 2017,
    },
    rules: {
        "linebreak-style": 0
    }
};